package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.CandlestickChartRepository;

//This class initializes the database with default values for candlestick chart if needed.

@Component
public class InitDBCandlestickChart {

	@Autowired
	private CandlestickChartRepository repository;
	
	@PostConstruct
	private void init() {
		
	}
}
