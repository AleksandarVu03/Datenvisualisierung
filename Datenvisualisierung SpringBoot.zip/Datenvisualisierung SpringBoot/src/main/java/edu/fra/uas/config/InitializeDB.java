package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.security.model.Role;
import edu.fra.uas.security.model.User;
import edu.fra.uas.security.repository.UserRepository;

@Component
public class InitializeDB {

	private static final Logger log = LoggerFactory.getLogger(InitializeDB.class);

	// Injecting UserRepository instance
	@Autowired
	UserRepository userRepository;

	// method to initialize the database with sample data
	@PostConstruct
	public void init() {
		log.debug(" >>> init database");

		// creating Admin user
		User user = new User();
		user.setNickname("admin");
		user.setEmail("admin@example.com");
		user.setPassword("admin");
		user.setRole(Role.ADMIN);
		userRepository.save(user);

		// creating sample user 1
		user = new User();
		user.setNickname("Prof. Dr. Lehmann");
		user.setEmail("lehmann@example.com");
		user.setPassword("lehmann");
		user.setRole(Role.USER);
		userRepository.save(user);

		// creating sample user 2
		user = new User();
		user.setNickname("bob");
		user.setEmail("bob@example.com");
		user.setPassword("bob");
		user.setRole(Role.USER);
		userRepository.save(user);

	}
}
