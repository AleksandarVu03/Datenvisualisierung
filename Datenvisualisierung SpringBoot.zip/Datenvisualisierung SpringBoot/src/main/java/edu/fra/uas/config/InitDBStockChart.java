package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.StockChartRepository;

//This class initializes the database with default values for stock chart if needed.

@Component
public class InitDBStockChart {

	@Autowired
	private StockChartRepository repository;

	@PostConstruct
	private void init() {

	}
}
