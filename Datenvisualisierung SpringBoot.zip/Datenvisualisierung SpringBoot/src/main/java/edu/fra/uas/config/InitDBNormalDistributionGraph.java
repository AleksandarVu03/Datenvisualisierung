package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.NormalDistributionGraphRepository;

//This class initializes the database with default values for normal distribution graph if needed.


@Component
public class InitDBNormalDistributionGraph {

	@Autowired
	private NormalDistributionGraphRepository repository;
	
	@PostConstruct
	private void init() {
		
	}
}
