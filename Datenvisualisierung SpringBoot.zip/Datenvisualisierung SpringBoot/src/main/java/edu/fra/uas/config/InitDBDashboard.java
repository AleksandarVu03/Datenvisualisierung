package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.DashboardRepository;

//This class initializes the database with default values for dashboard charts if needed.

@Component
public class InitDBDashboard {

	@Autowired
	private DashboardRepository repository;

	@PostConstruct
	private void init() {

	}
}
