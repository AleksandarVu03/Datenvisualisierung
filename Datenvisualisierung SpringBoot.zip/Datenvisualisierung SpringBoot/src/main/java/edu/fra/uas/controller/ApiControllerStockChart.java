package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.StockChart;
import edu.fra.uas.repository.StockChartRepository;

@RestController
@RequestMapping(value = "/api/stockChart", produces = MediaType.APPLICATION_JSON_VALUE)
public class ApiControllerStockChart {

	@Autowired
	private StockChartRepository repository;

	// GET request to retrieve all stock chart data
	@GetMapping
	@ResponseBody
	public ResponseEntity<List<StockChart>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);
	}

	// POST request to save stock chart data
	@PostMapping()
	public ResponseEntity<String> saveStockChart(@RequestBody StockChart stockChart) {
		this.repository.save(stockChart);
		return new ResponseEntity<>("Stock Chart is saved", HttpStatus.ACCEPTED);
	}

}
