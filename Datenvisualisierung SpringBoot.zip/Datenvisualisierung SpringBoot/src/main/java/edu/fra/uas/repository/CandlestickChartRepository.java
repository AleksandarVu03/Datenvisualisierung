package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.CandlestickChart;

public interface CandlestickChartRepository extends JpaRepository<CandlestickChart, Long> {
	

}
